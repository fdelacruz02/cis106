
![cover photo](carmen.garcia.jpg)

# Carmen Garcia

Allentown, PA 18104 ◆ +1 610 606 6747 ◆ cgarcia@accounting.com

## Professional Summary
Knowledgeable Certified Public Accountant with problem-solving abilities capable of building
customer rapport. Effectively handles customer concerns with clear communication and patience.
Able to take on various tasks at a customer-focused environment. Master in asset depreciation.

### Work History
**Asset Manager,** 08/2016 to Present *PNc Bank – Philadelphia,  PA*
* Offer advice to customers to ensure financial satisfaction.
* Increase sales 30% by being informative and persistent.
* Solved customer concerns and fixed issues reliably.


**Certified Public Accountant,** 11/2009 to 05/2020 *Anderson Financial - New York, New York*

* Managed 2 accounts that held $2.589 billion in assets and capital.
* Responded to customer requests for products, services and information.
* Educated customers on strategies, increasing revenue by 15%.

### Skills

| **Technical**   | **Communications**   |
| --------------- | -------------------- |
| Microsoft Suite | Complaint resolution |
| Tableau          | Sales expertise      |

### Education

| **Degree**       | **School**                                             | **Year** |
| ---------------- | ------------------------------------------------------ | -------- |
| Bachelors Degree | University of Pennsylvania Wharton School of Economics | 2004     |
| Masters Degree   | Harvard Business School                                | 2006     |
